export default interface ICoctail {
  strDrink: string
  strInstructions: string
  strDrinkThumb: string
  strIngredient1: string
  strIngredient2: string
  strIngredient3?: string
  strIngredient4?: string
  strIngredient5?: string
}
